bl_info = {
    "name": "RenderMage RM_Sync",
    "author": "RenderMage",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > RenderMage",
    "description": "Send active Blender viewport captures to RenderMage Studio.",
    "category": "Import-Export",
}

import http.server
import json
import os
import socketserver
import tempfile
import threading
import time
import urllib.parse

import bpy

CONNECTOR_VERSION = "1.0.0"
APP_NAME = "Blender"
BRIDGE_NAME = "blender-rm-sync"
BRIDGE_HOST = "127.0.0.1"
BRIDGE_PORT = 38124
CAPTURE_IMAGE_FILENAME = "capture.png"
CAPTURE_METADATA_FILENAME = "capture_meta.json"
CAPTURE_DIR = os.path.join(tempfile.gettempdir(), "RenderMage", "Blender", "rm_sync")
MAX_RETRY_ATTEMPTS = 5
RETRY_BACKOFF_SEC = 0.01

BRIDGE_STATE = {
    "server": None,
    "thread": None,
    "running": False,
    "connector_id": "",
}


def addon_preferences():
    addon = bpy.context.preferences.addons.get(__package__)
    if addon is None:
        raise RuntimeError("RenderMage RM_Sync is not available in Blender preferences.")
    return addon.preferences


def show_message(title, message):
    def draw(self, _context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title=title, icon="INFO")


def capture_image_path():
    return os.path.join(CAPTURE_DIR, CAPTURE_IMAGE_FILENAME)


def capture_metadata_path():
    return os.path.join(CAPTURE_DIR, CAPTURE_METADATA_FILENAME)


def ensure_capture_dir():
    os.makedirs(CAPTURE_DIR, exist_ok=True)


def safe_read(path, binary=False):
    attempts = 0
    mode = "rb" if binary else "r"
    encoding = None if binary else "utf-8"
    while True:
        try:
            with open(path, mode, encoding=encoding) as handle:
                return handle.read()
        except OSError:
            attempts += 1
            if attempts >= MAX_RETRY_ATTEMPTS:
                raise
            time.sleep(RETRY_BACKOFF_SEC)


def safe_write(path, data, binary=False):
    ensure_capture_dir()
    temp_path = f"{path}.tmp"
    attempts = 0
    mode = "wb" if binary else "w"
    encoding = None if binary else "utf-8"
    while True:
        try:
            with open(temp_path, mode, encoding=encoding) as handle:
                handle.write(data)
            os.replace(temp_path, path)
            return
        except OSError:
            attempts += 1
            if attempts >= MAX_RETRY_ATTEMPTS:
                raise
            time.sleep(RETRY_BACKOFF_SEC)


def read_capture_metadata():
    path = capture_metadata_path()
    if not os.path.exists(path):
        return None
    try:
        raw = safe_read(path)
        return json.loads(raw) if raw.strip() else None
    except (OSError, json.JSONDecodeError):
        return None


def clear_stale_capture_files():
    for path in (capture_image_path(), capture_metadata_path()):
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass


def ensure_connector_id():
    prefs = addon_preferences()
    if not prefs.connector_id:
        prefs.connector_id = f"blender-rm-sync-{int(time.time() * 1000)}"
    BRIDGE_STATE["connector_id"] = prefs.connector_id
    return prefs.connector_id


def local_bridge_status_payload():
    return {
        "success": True,
        "bridge": BRIDGE_NAME,
        "app_name": APP_NAME,
        "connector_id": BRIDGE_STATE["connector_id"],
        "connected": True,
        "capture": read_capture_metadata(),
    }


class RenderMageLocalBridgeServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class RenderMageLocalBridgeHandler(http.server.BaseHTTPRequestHandler):
    server_version = "RenderMageLocalBridge/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, _format, *_args):
        return

    def _origin(self):
        return self.headers.get("Origin", "*") or "*"

    def _send_headers(self, status, content_type, body_length=0, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Access-Control-Allow-Origin", self._origin())
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", self.headers.get("Access-Control-Request-Headers", "Content-Type, Accept"))
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Connection", "close")
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.send_header("Content-Length", str(body_length))
        self.end_headers()

    def do_OPTIONS(self):
        self._send_headers(204, "application/json", 0)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/health":
            body = json.dumps({
                **local_bridge_status_payload(),
                "latest_capture_id": (read_capture_metadata() or {}).get("id"),
            }).encode("utf-8")
            self._send_headers(200, "application/json", len(body))
            self.wfile.write(body)
            return

        if parsed.path == "/capture/status":
            body = json.dumps(local_bridge_status_payload()).encode("utf-8")
            self._send_headers(200, "application/json", len(body))
            self.wfile.write(body)
            return

        if parsed.path == "/capture/latest":
            metadata = read_capture_metadata()
            image_path = capture_image_path()
            if not metadata or not os.path.exists(image_path):
                body = json.dumps({"success": False, "error": "No capture available"}).encode("utf-8")
                self._send_headers(404, "application/json", len(body))
                self.wfile.write(body)
                return
            image_data = safe_read(image_path, binary=True)
            extra_headers = {
                "Content-Disposition": f"inline; filename=\"{metadata.get('file_name', 'capture.png')}\"",
                "X-RenderMage-Capture-Updated-At": metadata.get("updated_at", ""),
            }
            self._send_headers(200, metadata.get("mime_type", "image/png"), len(image_data), extra_headers)
            self.wfile.write(image_data)
            return

        body = json.dumps({"success": False, "error": "Not found"}).encode("utf-8")
        self._send_headers(404, "application/json", len(body))
        self.wfile.write(body)


def start_server():
    if BRIDGE_STATE["running"]:
        return True
    ensure_capture_dir()
    clear_stale_capture_files()
    ensure_connector_id()
    try:
        server = RenderMageLocalBridgeServer((BRIDGE_HOST, BRIDGE_PORT), RenderMageLocalBridgeHandler)
    except OSError:
        return False

    thread = threading.Thread(target=server.serve_forever, name="RenderMageBlenderBridge", daemon=True)
    thread.start()
    BRIDGE_STATE["server"] = server
    BRIDGE_STATE["thread"] = thread
    BRIDGE_STATE["running"] = True
    return True


def stop_server():
    if not BRIDGE_STATE["running"]:
        return False
    server = BRIDGE_STATE["server"]
    thread = BRIDGE_STATE["thread"]
    BRIDGE_STATE["running"] = False
    BRIDGE_STATE["server"] = None
    BRIDGE_STATE["thread"] = None
    if server is not None:
        server.shutdown()
        server.server_close()
    if thread is not None:
        thread.join(timeout=1.0)
    return True


def ensure_server_running():
    return start_server() or BRIDGE_STATE["running"]


def find_view3d_context():
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return window, screen, area, region
    raise RuntimeError("Open a 3D Viewport to send a capture to RenderMage.")


def capture_viewport_to_bridge():
    ensure_capture_dir()
    scene = bpy.context.scene
    window, screen, area, region = find_view3d_context()
    width = max(region.width, 1)
    height = max(region.height, 1)
    output_path = capture_image_path()
    file_name = f"rendermage_blender_capture_{int(time.time() * 1000)}.png"
    capture_id = f"blender_local_{int(time.time() * 1000)}"
    timestamp = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + f".{int((time.time() % 1) * 1000):03d}Z"

    original_path = scene.render.filepath
    original_format = scene.render.image_settings.file_format
    try:
        scene.render.filepath = output_path
        scene.render.image_settings.file_format = "PNG"
        with bpy.context.temp_override(window=window, screen=screen, area=area, region=region):
            bpy.ops.render.opengl(write_still=True, view_context=True)
    finally:
        scene.render.filepath = original_path
        scene.render.image_settings.file_format = original_format

    if not os.path.exists(output_path) or os.path.getsize(output_path) <= 0:
        raise RuntimeError("Blender could not export the current viewport.")

    metadata = {
        "id": capture_id,
        "file_name": file_name,
        "mime_type": "image/png",
        "width": width,
        "height": height,
        "source_app": APP_NAME,
        "updated_at": timestamp,
    }
    safe_write(capture_metadata_path(), json.dumps(metadata))


def send_current_viewport_capture():
    if not ensure_server_running():
        raise RuntimeError("RenderMage local bridge could not start.")
    capture_viewport_to_bridge()


class RenderMageRMSyncPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    connector_id: bpy.props.StringProperty(name="Connector ID", default="")

    def draw(self, _context):
        layout = self.layout
        layout.label(text="RenderMage RM_Sync")
        layout.label(text=f"Connector ID: {self.connector_id or 'Not initialized'}")
        layout.label(text=f"Bridge status: {'Running' if BRIDGE_STATE['running'] else 'Stopped'}")


class RENDERMAGE_RM_SYNC_OT_send_viewport(bpy.types.Operator):
    bl_idname = "rendermage_rm_sync.send_viewport"
    bl_label = "Send View to RenderMage"

    def execute(self, _context):
        ensure_connector_id()
        try:
            send_current_viewport_capture()
        except Exception as exc:  # noqa: BLE001
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, "Capture sent to RenderMage Studio.")
        return {"FINISHED"}


class RENDERMAGE_RM_SYNC_OT_stop_bridge(bpy.types.Operator):
    bl_idname = "rendermage_rm_sync.stop_bridge"
    bl_label = "Stop Bridge"

    def execute(self, _context):
        if stop_server():
            self.report({"INFO"}, "Local RenderMage bridge stopped.")
        else:
            self.report({"INFO"}, "Local RenderMage bridge is already stopped.")
        return {"FINISHED"}


class RENDERMAGE_RM_SYNC_PT_panel(bpy.types.Panel):
    bl_label = "RenderMage RM_Sync"
    bl_idname = "RENDERMAGE_RM_SYNC_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RenderMage"

    def draw(self, _context):
        layout = self.layout
        layout.label(text="Send the active viewport to Studio.")
        layout.operator("rendermage_rm_sync.send_viewport", icon="RENDER_STILL")
        layout.operator("rendermage_rm_sync.stop_bridge", icon="PANEL_CLOSE")
        layout.label(text=f"Bridge: {'Running' if BRIDGE_STATE['running'] else 'Stopped'}")


CLASSES = (
    RenderMageRMSyncPreferences,
    RENDERMAGE_RM_SYNC_OT_send_viewport,
    RENDERMAGE_RM_SYNC_OT_stop_bridge,
    RENDERMAGE_RM_SYNC_PT_panel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    ensure_connector_id()
    if not start_server():
        print(f"[RenderMage RM_Sync] Could not start local bridge on {BRIDGE_HOST}:{BRIDGE_PORT}")


def unregister():
    stop_server()
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
