bl_info = {
    "name": "RenderMage RM_Sync",
    "author": "RenderMage",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > RenderMage",
    "description": "Send active Blender viewport captures to RenderMage Studio.",
    "category": "Import-Export",
}

import base64
import json
import os
import tempfile
import time
import urllib.error
import urllib.request
import webbrowser

import bpy

API_DEFAULT = "https://www.rendermage.app/api"
CONNECTOR_VERSION = "1.0.0"
APP_NAME = "Blender"
PAIRING_STATE = {}


def addon_preferences():
    addon = bpy.context.preferences.addons.get(__package__)
    if addon is None:
        raise RuntimeError("RenderMage RM_Sync is not available in Blender preferences.")
    return addon.preferences


def show_message(title, message):
    def draw(self, _context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title=title, icon="INFO")


def request_json(path, payload=None, token=None):
    prefs = addon_preferences()
    url = f"{prefs.api_base.rstrip('/')}{path}"
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, method="POST")
    request.add_header("Content-Type", "application/json")
    if token:
        request.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            raw = response.read().decode("utf-8").strip()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8").strip()
        try:
            payload = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            payload = {}
        raise RuntimeError(payload.get("detail") or payload.get("error") or raw or str(exc)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(str(exc.reason)) from exc


def start_pairing(open_browser=True, send_after_pair=False):
    prefs = addon_preferences()
    response = request_json(
        "/connectors/browser/start",
        {
            "connector_id": prefs.connector_id,
            "app_name": APP_NAME,
            "app_version": bpy.app.version_string,
            "connector_version": CONNECTOR_VERSION,
        },
    )
    PAIRING_STATE.clear()
    PAIRING_STATE.update(
        {
            "pairing_id": response["pairing_id"],
            "device_secret": response["device_secret"],
            "started_at": time.time(),
            "send_after_pair": send_after_pair,
        }
    )
    if open_browser:
        webbrowser.open(response["approval_url"])
    register_pairing_poll()


def register_pairing_poll():
    def poll():
        if not PAIRING_STATE:
            return None
        if time.time() - PAIRING_STATE["started_at"] > 600:
            PAIRING_STATE.clear()
            show_message("RenderMage RM_Sync", "Sign-in timed out. Start RM_Sync again from Blender.")
            return None
        try:
            response = request_json(
                "/connectors/browser/poll",
                {
                    "pairing_id": PAIRING_STATE["pairing_id"],
                    "device_secret": PAIRING_STATE["device_secret"],
                },
            )
            if response.get("status") != "approved":
                return 2.0
            prefs = addon_preferences()
            prefs.connector_token = response["connector_token"]
            send_after_pair = bool(PAIRING_STATE.get("send_after_pair"))
            PAIRING_STATE.clear()
            if send_after_pair:
                try:
                    send_current_viewport_capture()
                    show_message("RenderMage RM_Sync", "RM_Sync connected. Your Blender view was sent to Studio.")
                except Exception as exc:  # noqa: BLE001
                    show_message("RenderMage RM_Sync", f"RM_Sync connected, but sending failed: {exc}")
                return None
            show_message("RenderMage RM_Sync", "RM_Sync connected. You can now send Blender views to RenderMage.")
            return None
        except Exception as exc:  # noqa: BLE001
            PAIRING_STATE.clear()
            show_message("RenderMage RM_Sync", f"Sign-in failed: {exc}")
            return None

    bpy.app.timers.register(poll, first_interval=2.0)


def find_view3d_context():
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return window, screen, area, region
    raise RuntimeError("Open a 3D Viewport to send a capture to RenderMage.")


def capture_viewport_to_file():
    scene = bpy.context.scene
    window, screen, area, region = find_view3d_context()
    width = max(region.width, 1)
    height = max(region.height, 1)
    file_name = f"rendermage_rm_sync_{int(time.time())}.png"
    output_path = os.path.join(tempfile.gettempdir(), file_name)

    original_path = scene.render.filepath
    original_format = scene.render.image_settings.file_format
    try:
        scene.render.filepath = output_path
        scene.render.image_settings.file_format = "PNG"
        with bpy.context.temp_override(window=window, screen=screen, area=area, region=region):
            bpy.ops.render.opengl(write_still=True, view_context=True)
        with open(output_path, "rb") as handle:
            payload = base64.b64encode(handle.read()).decode("ascii")
        return output_path, file_name, payload, width, height
    finally:
        scene.render.filepath = original_path
        scene.render.image_settings.file_format = original_format


def send_current_viewport_capture():
    prefs = addon_preferences()
    output_path = None
    try:
        output_path, file_name, image_base64, width, height = capture_viewport_to_file()
        request_json(
            "/connectors/capture",
            {
                "connector_id": prefs.connector_id,
                "app_name": APP_NAME,
                "app_version": bpy.app.version_string,
                "connector_version": CONNECTOR_VERSION,
                "file_name": file_name,
                "mime_type": "image/png",
                "image_base64": image_base64,
                "width": width,
                "height": height,
            },
            token=prefs.connector_token,
        )
    finally:
        if output_path and os.path.exists(output_path):
            os.remove(output_path)


class RenderMageRMSyncPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    api_base: bpy.props.StringProperty(name="API Base", default=API_DEFAULT)
    connector_id: bpy.props.StringProperty(name="Connector ID", default="")
    connector_token: bpy.props.StringProperty(name="Connector Token", default="", options={"HIDDEN"})

    def draw(self, _context):
        layout = self.layout
        layout.label(text="RenderMage RM_Sync")
        layout.prop(self, "api_base")
        layout.label(text=f"Connector ID: {self.connector_id or 'Not initialized'}")


class RENDERMAGE_RM_SYNC_OT_send_viewport(bpy.types.Operator):
    bl_idname = "rendermage_rm_sync.send_viewport"
    bl_label = "Send View to RenderMage"

    def execute(self, _context):
        prefs = addon_preferences()
        if not prefs.connector_id:
            prefs.connector_id = f"blender-rm-sync-{int(time.time() * 1000)}"
        if not prefs.connector_token:
            if PAIRING_STATE:
                self.report({"INFO"}, "Approve RM_Sync in your browser. Blender will send this view as soon as pairing completes.")
                return {"FINISHED"}
            try:
                start_pairing(open_browser=True, send_after_pair=True)
            except Exception as exc:  # noqa: BLE001
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}
            self.report({"INFO"}, "Approve RM_Sync in your browser. Blender will send this view automatically once connected.")
            return {"FINISHED"}

        try:
            send_current_viewport_capture()
        except Exception as exc:  # noqa: BLE001
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, "Capture sent to RenderMage Studio.")
        return {"FINISHED"}


class RENDERMAGE_RM_SYNC_OT_disconnect(bpy.types.Operator):
    bl_idname = "rendermage_rm_sync.disconnect"
    bl_label = "Disconnect RM_Sync"

    def execute(self, _context):
        prefs = addon_preferences()
        warning = None
        if prefs.connector_token:
            try:
                request_json("/connectors/disconnect", {}, token=prefs.connector_token)
            except Exception as exc:  # noqa: BLE001
                warning = str(exc)
        prefs.connector_token = ""
        if warning:
            self.report({"WARNING"}, f"Local token cleared. Cloud disconnect could not be confirmed: {warning}")
        else:
            self.report({"INFO"}, "RM_Sync disconnected from Blender.")
        return {"FINISHED"}


class RENDERMAGE_RM_SYNC_PT_panel(bpy.types.Panel):
    bl_label = "RenderMage RM_Sync"
    bl_idname = "RENDERMAGE_RM_SYNC_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "RenderMage"

    def draw(self, _context):
        layout = self.layout
        prefs = addon_preferences()
        layout.label(text="Send the active viewport to Studio.")
        layout.operator("rendermage_rm_sync.send_viewport", icon="RENDER_STILL")
        layout.operator("rendermage_rm_sync.disconnect", icon="PANEL_CLOSE")
        status = "Connected" if prefs.connector_token else "Not connected"
        layout.label(text=f"Status: {status}")


CLASSES = (
    RenderMageRMSyncPreferences,
    RENDERMAGE_RM_SYNC_OT_send_viewport,
    RENDERMAGE_RM_SYNC_OT_disconnect,
    RENDERMAGE_RM_SYNC_PT_panel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    prefs = addon_preferences()
    if not prefs.connector_id:
        prefs.connector_id = f"blender-rm-sync-{int(time.time() * 1000)}"


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
