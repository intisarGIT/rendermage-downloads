RenderMage RM_Sync for Blender

1. Open Blender Preferences > Extensions.
2. Install this ZIP package.
3. Open the RenderMage tab in the 3D View sidebar.
4. Click Send View to RenderMage.
5. If RM_Sync is not connected yet, approve the browser prompt and Blender will send the current view automatically.