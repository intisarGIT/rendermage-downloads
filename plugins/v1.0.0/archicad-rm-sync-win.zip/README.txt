RenderMage RM_Sync for Archicad 29 (Windows)

1. Open Archicad 29.
2. Go to Options > Add-On Manager and add RenderMage_RM_Sync.apx.
3. Close Add-On Manager and let Archicad load the add-on.
4. Open a 3D view.
5. Choose RenderMage > Send View to RenderMage.
6. Open RenderMage Studio on the same machine. Archicad will send the current view directly through localhost.