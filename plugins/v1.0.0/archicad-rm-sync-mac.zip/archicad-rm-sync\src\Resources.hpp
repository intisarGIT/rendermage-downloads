#pragma once

namespace RenderMage::RMSync {

constexpr short AddOnNameStringsResId = 32000;
constexpr short MenuStringsResId = 32500;

enum MenuItemIndex : short {
	MenuRoot = 0,
	SendViewMenuItem = 1,
	DisconnectMenuItem = 2
};

} // namespace RenderMage::RMSync
