# RenderMage RM_Sync for Archicad

This directory contains the Archicad 29 RM_Sync add-on source and release packaging files for Windows and macOS.

## Current state

- Windows add-on implementation for browser pairing, 3D capture, and RM_Sync upload
- CMake project layout based on the Archicad 29 DevKit examples
- release documentation and submission materials
- macOS bundle resource structure for final `.bundle` packaging
- local Windows build output at `build/win/Release/RenderMage_RM_Sync.apx` after compilation

## Build note

- Windows `.apx` builds can be produced locally with the Archicad 29 Windows DevKit, CMake, and Visual Studio Build Tools.
- macOS `.bundle` builds require a macOS host with the Archicad 29 macOS DevKit and signing/notarization setup.
