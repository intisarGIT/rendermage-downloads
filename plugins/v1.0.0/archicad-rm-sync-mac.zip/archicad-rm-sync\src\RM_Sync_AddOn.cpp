#include "APIEnvir.h"
#include "ACAPinc.h"

#include "Resources.hpp"

#include "DGModule.hpp"

#include "HTTP/Client/ClientConnection.hpp"
#include "HTTP/Client/Request.hpp"
#include "HTTP/Client/Response.hpp"
#include "JSON/JDOMParser.hpp"
#include "JSON/JDOMWriter.hpp"
#include "JSON/Value.hpp"
#include "MemoryOBinaryChannel.hpp"

#include "Base64Converter.hpp"

#include <algorithm>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <chrono>
#include <vector>

#if defined (WINDOWS)
#include <windows.h>
#include <shellapi.h>
#endif

#ifndef RM_SYNC_CONNECTOR_VERSION
#define RM_SYNC_CONNECTOR_VERSION "1.0.0"
#endif

#ifndef RM_SYNC_API_ORIGIN
#define RM_SYNC_API_ORIGIN "https://www.rendermage.app"
#endif

namespace RenderMage::RMSync {

namespace {

constexpr char ProductName[] = "RenderMage RM_Sync";
constexpr char AppName[] = "Archicad";
constexpr char AppVersion[] = "29";
constexpr char ApiPrefix[] = "/api";
constexpr std::size_t MaxUploadBytes = 5 * 1024 * 1024;
constexpr Int32 PreferencesVersion = 1;

struct StoredPreferences {
	UInt32 platformSign;
	char connectorId[128];
	char connectorToken[256];
	char pairingId[128];
	char deviceSecret[128];
	Int64 pairingExpiresAt;
};

struct RuntimeState {
	GS::UniString connectorId;
	GS::UniString connectorToken;
	GS::UniString pairingId;
	GS::UniString deviceSecret;
	Int64 pairingExpiresAt = 0;
};

struct RequestResult {
	bool ok = false;
	UInt32 statusCode = 0;
	GS::UniString message;
	JSON::ObjectValueRef body = new JSON::ObjectValue ();
};

RuntimeState g_state;

void Log (const GS::UniString& message)
{
	ACAPI_WriteReport ("[RenderMage RM_Sync] %s", false, message.ToCStr ().Get ());
}

GS::UniString Trimmed (GS::UniString value)
{
	value.Trim ();
	return value;
}

void CopyToBuffer (const GS::UniString& value, char* destination, std::size_t destinationSize)
{
	if (destination == nullptr || destinationSize == 0) {
		return;
	}

	const GS::UniString trimmed = Trimmed (value);
	const std::string utf8 = trimmed.ToCStr ().Get ();
	CHCopyC (utf8.c_str (), destination);
	destination[destinationSize - 1] = '\0';
}

GS::UniString ToUniString (const char* value)
{
	return value == nullptr ? GS::EmptyUniString : Trimmed (GS::UniString (value));
}

RuntimeState LoadPreferences ()
{
	RuntimeState state;
	StoredPreferences stored {};
	Int32 version = 0;
	GSSize bytes = 0;

	ACAPI_GetPreferences (&version, &bytes, nullptr);
	if (version == PreferencesVersion && bytes == sizeof (StoredPreferences)) {
		ACAPI_GetPreferences (&version, &bytes, &stored);
		if (stored.platformSign == GS::Act_Platform_Sign) {
			state.connectorId = ToUniString (stored.connectorId);
			state.connectorToken = ToUniString (stored.connectorToken);
			state.pairingId = ToUniString (stored.pairingId);
			state.deviceSecret = ToUniString (stored.deviceSecret);
			state.pairingExpiresAt = stored.pairingExpiresAt;
		}
	}

	return state;
}

void SavePreferences ()
{
	StoredPreferences stored {};
	stored.platformSign = GS::Act_Platform_Sign;
	CopyToBuffer (g_state.connectorId, stored.connectorId, sizeof (stored.connectorId));
	CopyToBuffer (g_state.connectorToken, stored.connectorToken, sizeof (stored.connectorToken));
	CopyToBuffer (g_state.pairingId, stored.pairingId, sizeof (stored.pairingId));
	CopyToBuffer (g_state.deviceSecret, stored.deviceSecret, sizeof (stored.deviceSecret));
	stored.pairingExpiresAt = g_state.pairingExpiresAt;
	ACAPI_SetPreferences (PreferencesVersion, sizeof (StoredPreferences), &stored);
}

GS::UniString GenerateConnectorId ()
{
	GS::Guid guid;
	guid.Generate ();
	return "archicad-rm-sync-" + guid.ToUniString ();
}

const GS::UniString& EnsureConnectorId ()
{
	if (g_state.connectorId.IsEmpty ()) {
		g_state.connectorId = GenerateConnectorId ();
		SavePreferences ();
	}
	return g_state.connectorId;
}

void ClearPendingPairing ()
{
	g_state.pairingId.Clear ();
	g_state.deviceSecret.Clear ();
	g_state.pairingExpiresAt = 0;
}

void ClearConnectionState ()
{
	g_state.connectorToken.Clear ();
	ClearPendingPairing ();
}

void ShowAlert (short alertType, const GS::UniString& title, const GS::UniString& message, const GS::UniString& details = GS::EmptyUniString)
{
	DGAlert (alertType, title, message, details, "OK");
}

bool OpenExternalUrl (const GS::UniString& url)
{
#if defined (WINDOWS)
	const auto result = reinterpret_cast<INT_PTR> (ShellExecuteW (nullptr, L"open", url.ToUStr ().Get (), nullptr, nullptr, SW_SHOWNORMAL));
	return result > 32;
#else
	UNUSED_PARAMETER (url);
	return false;
#endif
}

bool GetOptionalString (const JSON::ObjectValueRef& object, const GS::UniString& key, GS::UniString& outValue)
{
	if (object == nullptr) {
		return false;
	}

	return object->GetOptionalMember (key, outValue);
}

RequestResult PostJson (const GS::UniString& endpoint, const JSON::ObjectValueRef& payload, const GS::UniString& bearerToken = GS::EmptyUniString)
{
	RequestResult result;

	try {
		IO::URI::URI origin (GS::UniString (RM_SYNC_API_ORIGIN));
		HTTP::Client::ClientConnection clientConnection (origin);
		clientConnection.Connect ();

		HTTP::Client::Request request (HTTP::MessageHeader::Method::Post, GS::UniString (ApiPrefix) + endpoint);
		request.GetRequestHeaderFieldCollection ().Add ("Content-Type", "application/json;charset=utf-8");
		request.GetRequestHeaderFieldCollection ().Add ("Accept", "application/json");
		if (!bearerToken.IsEmpty ()) {
			request.GetRequestHeaderFieldCollection ().Add ("Authorization", GS::UniString ("Bearer ") + bearerToken);
		}

		GS::MemoryOBinaryChannel requestChannel;
		JSON::JDOMWriter requestWriter (*payload, requestChannel);
		clientConnection.Send (request, requestChannel.GetBuffer (), requestChannel.GetSize ());

		HTTP::Client::Response response;
		JSON::JDOMParser parser;
		JSON::ValueRef parsed = parser.Parse (clientConnection.BeginReceive (response));
		clientConnection.Close (false);

		result.statusCode = static_cast<UInt32> (response.GetStatusCode ());
		result.body = GS::DynamicCast<JSON::ObjectValue> (parsed);
		if (result.body == nullptr) {
			result.body = new JSON::ObjectValue ();
		}

		if (response.GetStatusCode () == HTTP::MessageHeader::StatusCode::OK) {
			result.ok = true;
			return result;
		}

		GS::UniString detail;
		if (!GetOptionalString (result.body, "detail", detail) && !GetOptionalString (result.body, "error", detail)) {
			detail = GS::UniString::Printf ("HTTP request failed (%d).", static_cast<Int32> (result.statusCode));
		}
		result.message = detail;
	} catch (const GS::Exception& exception) {
		result.message = exception.GetMessage ();
	} catch (const std::exception& exception) {
		result.message = exception.what ();
	} catch (...) {
		result.message = "Unexpected connector error.";
	}

	if (result.message.IsEmpty ()) {
		result.message = "RenderMage Studio did not return a usable response.";
	}

	return result;
}

bool Ensure3DWindow (short* width, short* height, GS::UniString* errorMessage)
{
	API_WindowInfo currentWindow {};
	GSErrCode err = ACAPI_Window_GetCurrentWindow (&currentWindow);
	if (err != NoError) {
		if (errorMessage != nullptr) {
			*errorMessage = GS::UniString::Printf ("Could not inspect the current Archicad window (%d).", err);
		}
		return false;
	}

	if (currentWindow.typeID != APIWind_3DModelID) {
		if (errorMessage != nullptr) {
			*errorMessage = "Open a 3D view in Archicad before sending it to RenderMage Studio.";
		}
		return false;
	}

	API_3DWindowInfo windowInfo {};
	err = ACAPI_View_Get3DWindowSets (&windowInfo);
	if (err != NoError) {
		if (errorMessage != nullptr) {
			*errorMessage = GS::UniString::Printf ("Could not read the current 3D viewport size (%d).", err);
		}
		return false;
	}

	if (width != nullptr) {
		*width = std::max<short> (windowInfo.hSize, 1);
	}
	if (height != nullptr) {
		*height = std::max<short> (windowInfo.vSize, 1);
	}
	return true;
}

IO::Location MakeTemporaryCaptureLocation (GS::UniString* fileName)
{
	API_SpecFolderID tempFolderId = API_TemporaryFolderID;
	IO::Location tempFolder;
	ACAPI_ProjectSettings_GetSpecFolder (&tempFolderId, &tempFolder);

	const auto timestamp = static_cast<long long> (std::time (nullptr));
	GS::UniString generatedName = GS::UniString::Printf ("rendermage_rm_sync_%lld.jpg", timestamp);
	if (fileName != nullptr) {
		*fileName = generatedName;
	}
	return IO::Location (tempFolder, IO::Name (generatedName));
}

bool ReadBinaryFile (const IO::Location& location, std::vector<char>* bytes, GS::UniString* errorMessage)
{
	GS::UniString path;
	location.ToPath (&path);
	const std::wstring widePath = path.ToUStr ().Get ();

	std::ifstream input (widePath, std::ios::binary);
	if (!input) {
		if (errorMessage != nullptr) {
			*errorMessage = "The rendered capture could not be read from disk.";
		}
		return false;
	}

	std::vector<char> data ((std::istreambuf_iterator<char> (input)), std::istreambuf_iterator<char> ());
	if (bytes != nullptr) {
		*bytes = std::move (data);
	}
	return true;
}

void DeleteFileIfPresent (const IO::Location& location)
{
	GS::UniString path;
	location.ToPath (&path);
	const std::wstring widePath = path.ToUStr ().Get ();
	std::error_code errorCode;
	std::filesystem::remove (widePath, errorCode);
}

bool CaptureCurrentView (GS::UniString* fileName, GS::UniString* imageBase64, short* width, short* height, GS::UniString* errorMessage)
{
	short captureWidth = 0;
	short captureHeight = 0;
	if (!Ensure3DWindow (&captureWidth, &captureHeight, errorMessage)) {
		return false;
	}

	GS::UniString generatedFileName;
	const IO::Location outputFile = MakeTemporaryCaptureLocation (&generatedFileName);

	API_PhotoRenderPars renderParameters {};
	renderParameters.fileTypeID = APIFType_JPEGFile;
	renderParameters.file = const_cast<IO::Location*> (&outputFile);
	renderParameters.colorDepth = APIColorDepth_TC24;
	renderParameters.dithered = false;

	const GSErrCode renderError = ACAPI_Rendering_PhotoRender (&renderParameters);
	if (renderError != NoError) {
		DeleteFileIfPresent (outputFile);
		if (errorMessage != nullptr) {
			*errorMessage = GS::UniString::Printf ("Archicad could not render the current 3D view (%d).", renderError);
		}
		return false;
	}

	std::vector<char> bytes;
	GS::UniString readError;
	const bool readOk = ReadBinaryFile (outputFile, &bytes, &readError);
	DeleteFileIfPresent (outputFile);
	if (!readOk) {
		if (errorMessage != nullptr) {
			*errorMessage = readError;
		}
		return false;
	}

	if (bytes.empty ()) {
		if (errorMessage != nullptr) {
			*errorMessage = "Archicad produced an empty capture file.";
		}
		return false;
	}

	if (bytes.size () > MaxUploadBytes) {
		if (errorMessage != nullptr) {
			*errorMessage = "The capture is larger than the hosted upload limit. Reduce the 3D window size and try again.";
		}
		return false;
	}

	GS::UniString encoded = Base64Converter::Encode (bytes.data (), static_cast<GS::USize> (bytes.size ()));
	encoded.ReplaceAll ("\n", "");
	encoded.ReplaceAll ("\r", "");

	if (fileName != nullptr) {
		*fileName = generatedFileName;
	}
	if (imageBase64 != nullptr) {
		*imageBase64 = encoded;
	}
	if (width != nullptr) {
		*width = captureWidth;
	}
	if (height != nullptr) {
		*height = captureHeight;
	}

	return true;
}

bool StartBrowserPairing ()
{
	JSON::ObjectValueRef payload = new JSON::ObjectValue ();
	payload->Add ("connector_id", EnsureConnectorId ());
	payload->Add ("app_name", AppName);
	payload->Add ("app_version", AppVersion);
	payload->Add ("connector_version", RM_SYNC_CONNECTOR_VERSION);

	const RequestResult response = PostJson ("/connectors/browser/start", payload);
	if (!response.ok) {
		ShowAlert (DG_ERROR, ProductName, "RM_Sync could not start browser sign-in.", response.message);
		return false;
	}

	GS::UniString pairingId;
	GS::UniString deviceSecret;
	GS::UniString approvalUrl;
	if (!GetOptionalString (response.body, "pairing_id", pairingId) ||
		!GetOptionalString (response.body, "device_secret", deviceSecret) ||
		!GetOptionalString (response.body, "approval_url", approvalUrl)) {
		ShowAlert (DG_ERROR, ProductName, "RenderMage Studio returned an incomplete pairing response.");
		return false;
	}

	g_state.pairingId = pairingId;
	g_state.deviceSecret = deviceSecret;
	g_state.pairingExpiresAt = static_cast<Int64> (std::time (nullptr)) + 600;
	SavePreferences ();

	if (!OpenExternalUrl (approvalUrl)) {
		ShowAlert (
			DG_WARNING,
			ProductName,
			"RM_Sync created a browser sign-in request, but Archicad could not open your browser automatically.",
			approvalUrl
		);
		return false;
	}

	ShowAlert (
		DG_INFORMATION,
		ProductName,
		"Approve RM_Sync in your browser. Archicad will send the current 3D view automatically after approval."
	);

	return true;
}

enum class PairingPollResult {
	Approved,
	Pending,
	Failed
};

PairingPollResult PollPendingPairing (bool showPendingMessage)
{
	if (g_state.pairingId.IsEmpty () || g_state.deviceSecret.IsEmpty ()) {
		return PairingPollResult::Failed;
	}

	if (g_state.pairingExpiresAt > 0 && static_cast<Int64> (std::time (nullptr)) > g_state.pairingExpiresAt) {
		ClearPendingPairing ();
		SavePreferences ();
		ShowAlert (DG_WARNING, ProductName, "Your RM_Sync sign-in request expired. Start Send View to RenderMage again.");
		return PairingPollResult::Failed;
	}

	JSON::ObjectValueRef payload = new JSON::ObjectValue ();
	payload->Add ("pairing_id", g_state.pairingId);
	payload->Add ("device_secret", g_state.deviceSecret);

	const RequestResult response = PostJson ("/connectors/browser/poll", payload);
	if (!response.ok) {
		ClearPendingPairing ();
		SavePreferences ();
		ShowAlert (DG_ERROR, ProductName, "RM_Sync could not confirm browser sign-in.", response.message);
		return PairingPollResult::Failed;
	}

	GS::UniString status;
	if (!GetOptionalString (response.body, "status", status)) {
		ShowAlert (DG_ERROR, ProductName, "RenderMage Studio returned an invalid pairing status.");
		return PairingPollResult::Failed;
	}

	if (status == "approved") {
		GS::UniString connectorToken;
		if (!GetOptionalString (response.body, "connector_token", connectorToken) || connectorToken.IsEmpty ()) {
			ShowAlert (DG_ERROR, ProductName, "RenderMage Studio approved the device but did not return a connector token.");
			return PairingPollResult::Failed;
		}

		g_state.connectorToken = connectorToken;
		ClearPendingPairing ();
		SavePreferences ();
		return PairingPollResult::Approved;
	}

	if (showPendingMessage) {
		ShowAlert (
			DG_INFORMATION,
			ProductName,
			"RM_Sync sign-in is still pending.",
			"Approve the request in your browser and Archicad will continue automatically."
		);
	}
	return PairingPollResult::Pending;
}

bool WaitForPendingPairingApproval ()
{
	const auto deadline = std::chrono::steady_clock::now () + std::chrono::minutes (10);
	while (std::chrono::steady_clock::now () < deadline) {
		switch (PollPendingPairing (false)) {
			case PairingPollResult::Approved:
				return true;
			case PairingPollResult::Failed:
				return false;
			case PairingPollResult::Pending:
				std::this_thread::sleep_for (std::chrono::seconds (2));
				break;
		}
	}

	ClearPendingPairing ();
	SavePreferences ();
	ShowAlert (DG_WARNING, ProductName, "RM_Sync sign-in timed out. Start Send View to RenderMage again.");
	return false;
}

bool EnsureConnectedForSend ()
{
	if (!g_state.connectorToken.IsEmpty ()) {
		return true;
	}

	if (!g_state.pairingId.IsEmpty ()) {
		return WaitForPendingPairingApproval ();
	}

	if (!StartBrowserPairing ()) {
		return false;
	}

	return WaitForPendingPairingApproval ();
}

void SendViewport ()
{
	if (!EnsureConnectedForSend ()) {
		return;
	}

	GS::UniString fileName;
	GS::UniString imageBase64;
	short width = 0;
	short height = 0;
	GS::UniString captureError;
	if (!CaptureCurrentView (&fileName, &imageBase64, &width, &height, &captureError)) {
		ShowAlert (DG_ERROR, ProductName, "RM_Sync could not capture the current Archicad view.", captureError);
		return;
	}

	JSON::ObjectValueRef payload = new JSON::ObjectValue ();
	payload->Add ("connector_id", EnsureConnectorId ());
	payload->Add ("app_name", AppName);
	payload->Add ("app_version", AppVersion);
	payload->Add ("connector_version", RM_SYNC_CONNECTOR_VERSION);
	payload->Add ("file_name", fileName);
	payload->Add ("mime_type", "image/jpeg");
	payload->Add ("image_base64", imageBase64);
	payload->Add ("width", width);
	payload->Add ("height", height);

	const RequestResult response = PostJson ("/connectors/capture", payload, g_state.connectorToken);
	if (!response.ok) {
		if (response.statusCode == 401 || response.statusCode == 403) {
			g_state.connectorToken.Clear ();
			SavePreferences ();
			ShowAlert (
				DG_WARNING,
				ProductName,
				"Your RM_Sync session is no longer valid.",
				"Choose Send View to RenderMage again in Archicad, then approve the new browser pairing."
			);
			return;
		}

		ShowAlert (DG_ERROR, ProductName, "RenderMage Studio rejected this capture.", response.message);
		return;
	}

	ShowAlert (DG_INFORMATION, ProductName, "Capture sent to RenderMage Studio.");
}

void DisconnectCommand ()
{
	GS::UniString remoteWarning;
	if (!g_state.connectorToken.IsEmpty ()) {
		JSON::ObjectValueRef payload = new JSON::ObjectValue ();
		const RequestResult response = PostJson ("/connectors/disconnect", payload, g_state.connectorToken);
		if (!response.ok) {
			remoteWarning = response.message;
		}
	}

	ClearConnectionState ();
	SavePreferences ();

	if (remoteWarning.IsEmpty ()) {
		ShowAlert (DG_INFORMATION, ProductName, "RM_Sync was disconnected from Archicad.");
	} else {
		ShowAlert (
			DG_WARNING,
			ProductName,
			"Your local RM_Sync token was cleared, but the cloud disconnect could not be confirmed.",
			remoteWarning
		);
	}
}

GSErrCode MenuCommandHandler (const API_MenuParams* menuParams)
{
	switch (menuParams->menuItemRef.menuResID) {
		case MenuStringsResId:
			switch (menuParams->menuItemRef.itemIndex) {
				case SendViewMenuItem:
					SendViewport ();
					break;
				case DisconnectMenuItem:
					DisconnectCommand ();
					break;
			}
			break;
	}

	return NoError;
}

} // namespace

API_AddonType CheckEnvironment (API_EnvirParams* envir)
{
	RSGetIndString (&envir->addOnInfo.name, AddOnNameStringsResId, 1, ACAPI_GetOwnResModule ());
	RSGetIndString (&envir->addOnInfo.description, AddOnNameStringsResId, 2, ACAPI_GetOwnResModule ());
	return APIAddon_Normal;
}

GSErrCode RegisterInterface ()
{
	return ACAPI_MenuItem_RegisterMenu (MenuStringsResId, 0, MenuCode_UserDef, MenuFlag_SeparatorBefore);
}

GSErrCode Initialize ()
{
	g_state = LoadPreferences ();
	EnsureConnectorId ();
	return ACAPI_MenuItem_InstallMenuHandler (MenuStringsResId, MenuCommandHandler);
}

GSErrCode FreeData ()
{
	return NoError;
}

} // namespace RenderMage::RMSync

API_AddonType CheckEnvironment (API_EnvirParams* envir)
{
	return RenderMage::RMSync::CheckEnvironment (envir);
}

GSErrCode RegisterInterface ()
{
	return RenderMage::RMSync::RegisterInterface ();
}

GSErrCode Initialize ()
{
	return RenderMage::RMSync::Initialize ();
}

GSErrCode FreeData ()
{
	return RenderMage::RMSync::FreeData ();
}
