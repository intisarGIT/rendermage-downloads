RenderMage RM_Sync for Archicad 29 (macOS)

This package contains the final macOS project files for RM_Sync.
The signed .bundle must be built and notarized on a Mac with the Archicad 29 macOS DevKit before public release.